export default async (request) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors });
  }

  if (request.method !== "POST") {
    return Response.json(
      { error: "Method not allowed. Send a POST request." },
      { status: 405, headers: cors }
    );
  }

  try {
    const body = await request.json();
    const message = body?.message;

    if (typeof message !== "string" || !message.trim() || message.length > 1000) {
      return Response.json(
        { error: "Message must contain 1 to 1000 characters." },
        { status: 400, headers: cors }
      );
    }

    if (!process.env.AI_API_KEY) {
      return Response.json(
        { error: "Server configuration error: AI_API_KEY is missing." },
        { status: 500, headers: cors }
      );
    }

    const groqResponse = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.AI_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "llama-3.3-70b-versatile",
          messages: [
            {
              role: "system",
              content: "Tu es un assistant sympathique. Réponds en français de manière claire et concise."
            },
            { role: "user", content: message.trim() }
          ],
          max_tokens: 300
        })
      }
    );

    if (!groqResponse.ok) {
      // Do not expose provider details or the API key to the browser.
      return Response.json(
        { error: "The AI provider returned an error. Check your model and API account." },
        { status: 502, headers: cors }
      );
    }

    const data = await groqResponse.json();
    const reply = data?.choices?.[0]?.message?.content;

    return Response.json(
      { reply: typeof reply === "string" ? reply : "Je n'ai pas reçu de réponse." },
      { status: 200, headers: cors }
    );
  } catch {
    return Response.json(
      { error: "Invalid request or temporary server error." },
      { status: 400, headers: cors }
    );
  }
};
